<?php
$arquivo_json = "horarios.json";
$horarios = json_decode(file_get_contents($arquivo_json), true);

$id = $_GET["id"] ?? null;

if ($id === null) {
    die("ID inválido.");
}

$novos = [];

foreach ($horarios as $h) {
    if ($h["id"] != $id) {
        $novos[] = $h;
    }
}

file_put_contents($arquivo_json, json_encode($novos, JSON_PRETTY_PRINT));

header("Location: horarios-listar.php");
exit;
