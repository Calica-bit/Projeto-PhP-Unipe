<?php
$arquivo_json = "cortes.json";
$cortes = json_decode(file_get_contents($arquivo_json), true);

$id = $_GET["id"] ?? null;

if ($id === null) {
    die("ID inválido.");
}

$novos = [];

foreach ($cortes as $c) {
    if ($c["id"] != $id) {
        $novos[] = $c;
    }
}

file_put_contents($arquivo_json, json_encode($novos, JSON_PRETTY_PRINT));

header("Location: cortes-listar.php");
exit;
