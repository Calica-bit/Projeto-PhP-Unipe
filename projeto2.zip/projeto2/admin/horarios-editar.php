<?php
$arquivo_json = "horarios.json";
$horarios = json_decode(file_get_contents($arquivo_json), true);

$id = $_GET["id"] ?? null;

if ($id === null) {
    die("ID inválido.");
}

$horario = null;
foreach ($horarios as $h) {
    if ($h["id"] == $id) {
        $horario = $h;
        break;
    }
}

if (!$horario) {
    die("Horário não encontrado!");
}

$dias = ["terça", "quarta", "quinta", "sexta", "sábado"];

$horas = [];
for ($i = 9; $i <= 21; $i++) {
    $horas[] = $i . ":00";
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    foreach ($horarios as &$h) {
        if ($h["id"] == $id) {
            $h["dia"] = $_POST["dia"];
            $h["hora"] = $_POST["hora"];
        }
    }

    file_put_contents($arquivo_json, json_encode($horarios, JSON_PRETTY_PRINT));

    header("Location: horarios-listar.php");
    exit;
}
?>

<h1>Editar horário</h1>

<form method="POST">
    Dia da semana: <br>
    <select name="dia" required>
        <?php foreach ($dias as $d): ?>
            <option value="<?= $d ?>" <?= $horario['dia'] == $d ? "selected" : "" ?>>
                <?= ucfirst($d) ?>
            </option>
        <?php endforeach; ?>
    </select><br><br>

    Horário: <br>
    <select name="hora" required>
        <?php foreach ($horas as $h): ?>
            <option value="<?= $h ?>" <?= $horario['hora'] == $h ? "selected" : "" ?>>
                <?= $h ?>
            </option>
        <?php endforeach; ?>
    </select><br><br>

    <button type="submit">Salvar Alterações</button>
</form>

<br>
<a href="horarios-listar.php">Voltar</a>
