<?php
$arquivo_json = "produtos.json";
$produtos = json_decode(file_get_contents($arquivo_json), true);

$id = $_GET["id"] ?? null;

if ($id === null) {
    die("ID inválido.");
}

$novos = [];

foreach ($produtos as $p) {
    if ($p["id"] != $id) {
        $novos[] = $p;
    }
}

file_put_contents($arquivo_json, json_encode($novos, JSON_PRETTY_PRINT));

header("Location: produtos-listar.php");
exit;
