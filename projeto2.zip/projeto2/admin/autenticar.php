<?php
session_start();

$usuario_correto = "barbeariaunipe";
$senha_correta   = "2025";

$usuario = $_POST['usuario'];
$senha   = $_POST['senha'];

if ($usuario === $usuario_correto && $senha === $senha_correta) {
    $_SESSION['logado'] = true;
    header("Location: index.php");
    exit;
} else {
    echo "Usuário ou senha incorretos! <br>";
    echo "<a href='login.php'>Tentar novamente</a>";
}
