<?php

$arquivo_json = "cortes.json";

$cortes = [];

if (file_exists($arquivo_json)) {
    $cortes = json_decode(file_get_contents($arquivo_json), true);
}

echo '<h1>Lista de Cortes</h1>';
echo "<a href='cortes-cadastro-form.php'>Cadastrar cortes</a><br><br>";

?>

<h2>Cortes cadastrados</h2>
<ul>
<?php foreach ($cortes as $corte): ?>
    <li>
        Nome: <?= $corte['nome'] ?? '' ?><br>
        Preço: <?= $corte['preco'] ?? '' ?><br>

        <a href="cortes-editar.php?id=<?= $corte['id'] ?>"
           onclick="return confirm('Deseja realmente editar este corte?')">
           Editar /
        <a href="cortes-excluir.php?id=<?= $corte['id'] ?>"
           onclick="return confirm('Tem certeza que deseja excluir este corte?')">
           Excluir
        </a>
        <br><br>
    </li>
<?php endforeach; ?>
</ul>
