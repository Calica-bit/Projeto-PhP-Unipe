<?php

$arquivo_json = "horarios.json";

$horarios = [];

if (file_exists($arquivo_json)) {
    $horarios = json_decode(file_get_contents($arquivo_json), true);
}

echo '<h1>Lista de horários</h1>';
echo "<a href='horarios-cadastro-form.php'>Cadastrar  horário</a><br><br>";

?>

<h2> Horários cadastrados</h2>
<ul>
<?php foreach ($horarios as $horario): ?>
    <li>
        Dia da semana: <?= $horario['dia'] ?? '' ?><br>
        horário: <?= $horario['hora'] ?? '' ?><br>

        <a href="horarios-editar.php?id=<?= $horario['id'] ?>"
           onclick="return confirm('Deseja realmente editar este horário?')">
           Editar /
        <a href="horarios-excluir.php?id=<?= $horario['id'] ?>"
           onclick="return confirm('Tem certeza que deseja excluir este  horário?')">
           Excluir
        </a>
        <br><br>
    </li>
<?php endforeach; ?>
</ul>
