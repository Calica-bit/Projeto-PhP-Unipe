<header style="background-color: #7aa700ff; height: 150px">

<?php 
session_start();
if (!isset($_SESSION['logado']) || $_SESSION['logado'] !== true) {
    header("Location: login.php");
    exit;
    }

echo "<h1>Painel do Administrador</h1>";
?>

    <li><a href="cortes-listar.php">Gerenciar Cortes / Preços</a><br><br>
    <li><a href="horarios-listar.php">Gerenciar Horários</a><br><br>
    <li><a href="produtos-listar.php">Gerenciar produtos</a><br><br>

<a href="logout.php">Sair</a>
