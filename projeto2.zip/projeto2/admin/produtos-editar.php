<?php
$arquivo_json = "produtos.json";

if (!file_exists($arquivo_json)) {
    die("Arquivo produtos.json não encontrado.");
}

$produtos = json_decode(file_get_contents($arquivo_json), true);

$id = $_GET["id"] ?? null;

if ($id === null) {
    die("ID inválido.");
}

$produto = null;
foreach ($produtos as $p) {
    if ($p["id"] == $id) {
        $produto = $p;
        break;
    }
}

if (!$produto) {
    die("Produto não encontrado!");
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    foreach ($produtos as &$p) {
        if ($p["id"] == $id) {
            $p["nome"] = $_POST["nome"];
            $p["preco"] = $_POST["preco"];
        }
    }

    file_put_contents($arquivo_json, json_encode($produtos, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

    header("Location: produtos-listar.php");
    exit;
}
?>
<h1>Editar produto</h1>

<form method="POST">
    Nome: <br>
    <input type="text" name="nome" value="<?= $produto['nome'] ?>" required><br><br>

    Preço: <br>
    <input type="number" name="preco" step="0.01" value="<?= $produto['preco'] ?>" required><br><br>

    <button type="submit">Salvar Alterações</button>
</form>

<br>
<a href="produtos-listar.php">Voltar</a>
