<?php
$dias = ["terça", "quarta", "quinta", "sexta", "sábado"];
?>

<h1>Cadastrar horário</h1>

<form action="horarios-cadastro.php" method="POST">
    Dia da semana:
    <select name="dia" required>
        <?php foreach ($dias as $d): ?>
            <option value="<?= $d ?>"><?= $d ?></option>
        <?php endforeach; ?>
    </select><br><br>

    Horário:
    <select name="hora" required>
        <?php for ($i = 9; $i <= 21; $i++): ?>
            <option value="<?= $i ?>:00"><?= $i ?>:00</option>
        <?php endfor; ?>
    </select><br><br>

    <button type="submit">Salvar</button>
</form>
