<?php

   echo "<h1>Cadastrar Produtos</h1>";

   ?>
   <form method="post" action="produtos-cadastro.php">
       <label>Nome : </label>
       <input type="text" name="nome" ><br>
       <label>preço : </label>
       <input type="text" name="preco" ><br>

    <input type="submit" value="cadastrar">
    </form>