<?php

$arquivo_json = "horarios.json";

$dia = $_POST['dia'];
$hora = $_POST['hora'];

$horarios = [];


if (file_exists($arquivo_json) && filesize($arquivo_json) > 0) {
    $json = file_get_contents($arquivo_json);
    $horarios = json_decode($json, true);

    if (!is_array($horarios)) {
        $horarios = [];
    }
}


$novo_id = count($horarios) + 1;
$novo_horario = [
    "id" => $novo_id,
    "dia" => $dia,
    "hora" => $hora,

];


$horarios[] = $novo_horario;


$horarios_json = json_encode($horarios, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);


if (file_put_contents($arquivo_json, $horarios_json)) {
    echo "<p><strong>$dia</strong> cadastrado com sucesso.</p>";
    echo "<p><a href='horarios-listar.php'>Lista de horário</a>";
} else {
    echo "<h2>Erro ao salvar o horário</h2>";
    echo "<p><a href='horarios-listar.php'>Lista de horário</a>";
}

?>
