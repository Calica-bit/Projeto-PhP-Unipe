<?php

$arquivo_json = "cortes.json";

$nome = $_POST['nome'];
$preco = $_POST['preco'];

$cortes = [];


if (file_exists($arquivo_json) && filesize($arquivo_json) > 0) {
    $json = file_get_contents($arquivo_json);
    $cortes = json_decode($json, true);

    if (!is_array($cortes)) {
        $cortes = [];
    }
}


$novo_id = count($cortes) + 1;
$novo_corte = [
    "id" => $novo_id,
    "nome" => $nome,
    "preco" => $preco,

];


$cortes[] = $novo_corte;


$cortes_json = json_encode($cortes, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);


if (file_put_contents($arquivo_json, $cortes_json)) {
    echo "<p><strong>$nome</strong> cadastrado com sucesso.</p>";
    echo "<p><a href='cortes-listar.php'>Lista de cortes</a>";
} else {
    echo "<h2>Erro ao salvar o corte</h2>";
    echo "<p><a href='cortes-listar.php'>Lista de cortes</a>";
}

?>
