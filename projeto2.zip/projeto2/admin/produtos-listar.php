<?php

$arquivo_json = "produtos.json";

$produtos = [];

if (file_exists($arquivo_json)) {
    $produtos = json_decode(file_get_contents($arquivo_json), true);
}

echo '<h1>Lista de produtos</h1>';
echo "<a href='produtos-cadastro-form.php'>Cadastrar produtos</a><br><br>";

?>

<h2>Produtos cadastrados</h2>
<ul>
<?php foreach ($produtos as $produto): ?>
    <li>
        Nome: <?= $produto['nome'] ?? '' ?><br>
        Preço: <?= $produto['preco'] ?? '' ?><br>

        <a href="produtos-editar.php?id=<?= $produto['id'] ?>"
           onclick="return confirm('Tem certeza que deseja excluir este produto?')">
           Editar /
        <a href="produtos-excluir.php?id=<?= $produto['id'] ?>"
           onclick="return confirm('Tem certeza que deseja excluir este produto?')">
           Excluir
        </a>
        <br><br>
    </li>
<?php endforeach; ?>
</ul>
