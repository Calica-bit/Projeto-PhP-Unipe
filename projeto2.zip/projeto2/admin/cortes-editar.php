<?php
$arquivo_json = "cortes.json";
$cortes = json_decode(file_get_contents($arquivo_json), true);

$id = $_GET["id"] ?? null;

if ($id === null) {
    die("ID inválido.");
}


$corte = null;
foreach ($cortes as $c) {
    if ($c["id"] == $id) {
        $corte = $c;
        break;
    }
}

if (!$corte) {
    die("Corte não encontrado!");
}


if ($_SERVER["REQUEST_METHOD"] === "POST") {

    foreach ($cortes as &$c) {
        if ($c["id"] == $id) {
            $c["nome"] = $_POST["nome"];
            $c["preco"] = $_POST["preco"];
        }
    }

    file_put_contents($arquivo_json, json_encode($cortes, JSON_PRETTY_PRINT));

    header("Location: cortes-listar.php");
    exit;
}
?>

<h1>Editar Corte</h1>

<form method="POST">
    Nome: <br>
    <input type="text" name="nome" value="<?= $corte['nome'] ?>" required><br><br>

    Preço: <br>
    <input type="number" name="preco" step="0.01" value="<?= $corte['preco'] ?>" required><br><br>

    <button type="submit">Salvar Alterações</button>
</form>

<br>
<a href="cortes-listar.php">Voltar</a>
