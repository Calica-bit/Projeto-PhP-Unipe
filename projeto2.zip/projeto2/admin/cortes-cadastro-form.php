<?php

   echo "<h2>cadastro dos cortes</h2>";

   ?>
   <form method="post" action="cortes-cadastro.php">
       <label>Nome : </label>
       <input type="text" name="nome" ><br>
       <label>preço : </label>
       <input type="text" name="preco" ><br>

    <input type="submit" value="cadastrar">
    </form>