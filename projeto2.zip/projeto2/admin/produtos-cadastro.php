<?php

$arquivo_json = "produtos.json";

$nome = $_POST['nome'];
$preco = $_POST['preco'];

$produtos = [];


if (file_exists($arquivo_json) && filesize($arquivo_json) > 0) {
    $json = file_get_contents($arquivo_json);
    $produtos = json_decode($json, true);

    if (!is_array($produtos)) {
        $produtos = [];
    }
}


$novo_id = count($produtos) + 1;
$novo_produto = [
    "id" => $novo_id,
    "nome" => $nome,
    "preco" => $preco,

];


$produtos[] = $novo_produto;


$produtos_json = json_encode($produtos, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);


if (file_put_contents($arquivo_json, $produtos_json)) {
    echo "<p><strong>$nome</strong> cadastrado com sucesso.</p>";
    echo "<p><a href='produtos-listar.php'>Lista de produtos</a>";
} else {
    echo "<h2>Erro ao salvar o produto</h2>";
    echo "<p><a href='produtos-listar.php'>Lista de produtos</a>";
}

?>
